package vo;

public class ShoppingCartVO {
	private int shopNum, bookNum, bookCnt;
	private String id, regdate_cart;
	
	public int getShopNum() {
		return shopNum;
	}
	public void setShopNum(int shopNum) {
		this.shopNum = shopNum;
	}
	public int getBookNum() {
		return bookNum;
	}
	public void setBookNum(int bookNum) {
		this.bookNum = bookNum;
	}
	public int getBookCnt() {
		return bookCnt;
	}
	public void setBookCnt(int bookCnt) {
		this.bookCnt = bookCnt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRegdate_cart() {
		return regdate_cart;
	}
	public void setRegdate_cart(String regdate_cart) {
		this.regdate_cart = regdate_cart;
	}
	
	
}
